from django.contrib import admin
from status.models import Member

# Register your models here.

admin.site.register(Member)