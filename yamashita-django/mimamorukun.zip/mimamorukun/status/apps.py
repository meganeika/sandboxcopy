from django.apps import AppConfig


class StatusConfig(AppConfig):
    name = 'status'
